"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { ThemeToggle } from "./ThemeToggle";
import { Button } from "./ui/button";
import { ProtectedAction } from "@/components/auth/ProtectedAction";
import { ProfileDropdown } from "@/components/auth/ProfileDropdown";
import { useSession } from "next-auth/react";
import { Menu, X, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/lib/supabase";

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const { status } = useSession();

  useEffect(() => {
    async function fetchLogo() {
      const { data } = await supabase.from("website_settings").select("logo_url").limit(1).single();
      if (data?.logo_url) setLogoUrl(data.logo_url);
    }
    fetchLogo();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
    document.body.style.overflow = '';
  }, [pathname]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isMobileMenuOpen]);

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "Fleet", href: "/fleet" },
    { name: "Packages", href: "/packages" },
    { name: "History", href: "/history" },
    { name: "Gallery", href: "/gallery" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <>
      <header
        className={cn(
          "fixed left-0 right-0 top-0 z-50 transition-all duration-300 ease-in-out",
          isScrolled
            ? "bg-bg/80 backdrop-blur-xl shadow-sm border-b border-border/50 py-2 md:py-3"
            : "bg-transparent py-3 md:py-5"
        )}
      >
        <div className="container mx-auto px-4 lg:px-6 max-w-[1600px] flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group z-50 relative">
            {logoUrl ? (
              <Image src={logoUrl} alt="Logo" width={200} height={40} className="h-7 sm:h-8 md:h-10 w-auto object-contain transition-opacity duration-300 hover:opacity-90" />
            ) : (
              <div className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-display font-bold text-accent-primary transition-colors shrink-0">
                Jyotirling<span className="text-ink group-hover:text-accent-secondary transition-colors">Connect</span>
              </div>
            )}
          </Link>

          {/* Desktop Nav — hidden until lg (1024px) */}
          <nav className="hidden lg:flex items-center gap-5 xl:gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className={cn(
                  "text-sm font-semibold transition-all hover:text-accent-secondary relative group",
                  pathname === link.href ? "text-accent-primary" : "text-ink"
                )}
              >
                {link.name}
                <span 
                  className={cn(
                    "absolute -bottom-1 left-0 h-[2px] bg-accent-primary transition-all duration-300",
                    pathname === link.href ? "w-full" : "w-0 group-hover:w-full"
                  )} 
                />
              </Link>
            ))}
          </nav>

          {/* Desktop Actions — hidden until lg (1024px) */}
          <div className="hidden lg:flex items-center gap-4">
            <ThemeToggle />
            <ProtectedAction href="/booking" className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground h-9 px-4 py-2 rounded-xl shadow-md hover:shadow-lg transition-all hover:-translate-y-0.5">
              Book Your Yatra
            </ProtectedAction>
            {status === "authenticated" && <ProfileDropdown />}
          </div>

          {/* Mobile Toggle & Theme — visible until lg (1024px) */}
          <div className="flex lg:hidden items-center gap-2 sm:gap-3 z-50 relative">
            <ThemeToggle />
            {status === "authenticated" && <ProfileDropdown />}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-ink p-2 -mr-1 min-w-[44px] min-h-[44px] flex items-center justify-center hover:bg-surface/50 rounded-lg transition-colors"
              aria-label="Toggle Menu"
              aria-expanded={isMobileMenuOpen}
            >
              <AnimatePresence mode="wait">
                {isMobileMenuOpen ? (
                  <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.2 }}>
                    <X size={24} />
                  </motion.div>
                ) : (
                  <motion.div key="menu" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.2 }}>
                    <Menu size={24} />
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          </div>
        </div>
      </header>

      {/* Premium Mobile Menu Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 md:hidden"
              onClick={() => setIsMobileMenuOpen(false)}
            />

            {/* Drawer */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 bottom-0 w-[80vw] max-w-[360px] bg-bg border-l border-border/50 z-40 lg:hidden shadow-2xl flex flex-col pt-20 pb-8 px-5 overflow-y-auto overscroll-contain"
            >
              <div className="flex flex-col space-y-2 flex-grow">
                {navLinks.map((link, i) => (
                  <motion.div
                    key={link.name}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 + (i * 0.05), duration: 0.3 }}
                  >
                    <Link
                      href={link.href}
                      className={cn(
                        "flex items-center justify-between py-4 text-xl font-display font-semibold transition-all border-b border-border/50 group",
                        pathname === link.href ? "text-accent-primary border-accent-primary/20" : "text-ink hover:text-accent-primary"
                      )}
                    >
                      {link.name}
                      <ChevronRight size={18} className={cn("transition-transform group-hover:translate-x-1", pathname === link.href ? "text-accent-primary opacity-100" : "text-ink-muted opacity-0 group-hover:opacity-50")} />
                    </Link>
                  </motion.div>
                ))}
              </div>
              
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.3 }}
                className="pt-8 mt-auto"
              >
                <ProtectedAction href="/booking" className="inline-flex items-center justify-center whitespace-nowrap font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground px-8 py-2 w-full h-14 text-lg rounded-xl shadow-lg shadow-accent-primary/20">
                  Book Your Yatra
                </ProtectedAction>
                <p className="text-center text-xs text-ink-muted mt-6 uppercase tracking-wider font-semibold">
                  Premium Pilgrimage Services
                </p>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
